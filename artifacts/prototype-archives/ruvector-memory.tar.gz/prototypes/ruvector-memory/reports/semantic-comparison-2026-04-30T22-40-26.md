# RuVector Semantic Prototype vs Stage 3A Report

Generated: 2026-04-30T22:40:26.755Z

## Summary

- Model: nomic-embed-text:latest
- Dimensions: 768
- Semantic chunks: 398
- Evaluation queries: 10
- Source overlap range: 25.0% - 100.0%
- Average source overlap: 57.5%

## Results

| ID | Query | Semantic Sources | Stage 3A Sources | Overlap | Top Score |
|----|-------|------------------|------------------|---------|-----------|
| rag-001 | What is the safe operating model for local... | OPENCODE_GEMMA_NOTES.md, GEMMA_LOCAL_AGENT.md | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md | 100.0% | 0.8347 |
| rag-002 | Where should generated security reports go... | FINAL_POLICY.md, chunks.jsonl (Stage 3A), GEMMA_LOCAL_AGENT.md | GEMMA_LOCAL_AGENT.md, FINAL_POLICY.md | 50.0% | 0.7578 |
| rag-003 | Which package manager should be used on Ba... | FINAL_POLICY.md, chunks.jsonl (Stage 3A), OPENCODE_GEMMA_NOTES.md | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md | 50.0% | 0.7006 |
| rag-004 | What should Gemma do if evidence is missin... | GEMMA_LOCAL_AGENT.md, OPERATIONS.md | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md, OPERATIONS.md | 66.7% | 0.6739 |
| rag-005 | What firewall tool does Bazzite use? | FINAL_POLICY.md, chunks.jsonl (Stage 3A) | GEMMA_LOCAL_AGENT.md, OPERATIONS.md, OPENCODE_GEMMA_NOTES.md | 25.0% | 0.7143 |
| path-001 | Where should generated security reports go... | FINAL_POLICY.md, chunks.jsonl (Stage 3A), GEMMA_LOCAL_AGENT.md | GEMMA_LOCAL_AGENT.md, FINAL_POLICY.md | 50.0% | 0.7578 |
| path-002 | Where should Gemma wrapper scripts be inst... | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md | 100.0% | 0.6520 |
| path-003 | Where should security configuration files ... | PATHS.md, chunks.jsonl (Stage 3A), FINAL_POLICY.md | GEMMA_LOCAL_AGENT.md, FINAL_POLICY.md | 33.3% | 0.7100 |
| path-004 | Where should security logs be written? | GEMMA_LOCAL_AGENT.md, OPERATIONS.md, FINAL_POLICY.md | GEMMA_LOCAL_AGENT.md, FINAL_POLICY.md | 50.0% | 0.6674 |
| path-005 | Where should the knowledge pack index be s... | GEMMA_LOCAL_AGENT.md, OPENCODE_GEMMA_NOTES.md | GEMMA_LOCAL_AGENT.md | 50.0% | 0.6475 |

## Notes

- Semantic retrieval used the already-installed local Ollama model `nomic-embed-text:latest`.
- Stage 3A remains the canonical fallback.
- This is a scoped prototype, not production memory.
